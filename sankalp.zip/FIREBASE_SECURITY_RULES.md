# Firebase Firestore Security Rules for Sadhana

## Complete Security Rules Configuration

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions for validation
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function isOwner(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }
    
    function isValidEmail(email) {
      return email.matches('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$');
    }
    
    function isValidPriority(priority) {
      return priority in ['brahma', 'vishnu', 'shiva', 'indra'];
    }
    
    function isValidStatus(status) {
      return status in ['notStarted', 'inProgress', 'completed', 'cancelled'];
    }
    
    function isValidDate(date) {
      return date is timestamp;
    }
    
    // Users Collection Rules
    match /users/{userId} {
      allow read: if isOwner(userId);
      
      allow create: if isAuthenticated() 
                    && request.auth.uid == userId
                    && request.resource.data.keys().hasOnly([
                      'email',
                      'displayName',
                      'createdAt',
                      'lastLogin',
                      'preferences'
                    ]);
      
      allow update: if isOwner(userId)
                    && request.resource.data.keys().hasAny([
                      'displayName',
                      'lastLogin',
                      'preferences'
                    ]);
      
      allow delete: if isOwner(userId);
    }
    
    // Tasks Collection Rules
    match /tasks/{taskId} {
      // Allow read if user owns the task or is assigned to it
      allow read: if isAuthenticated() && (
        resource.data.userId == request.auth.uid ||
        resource.data.assignedTo == request.auth.token.email ||
        request.auth.token.email == resource.data.assignedTo
      );
      
      // Allow create if user is authenticated and is setting themselves as owner
      allow create: if isAuthenticated() 
                    && request.resource.data.userId == request.auth.uid
                    && isValidPriority(request.resource.data.priority)
                    && isValidStatus(request.resource.data.status)
                    && (request.resource.data.dueDate == null || isValidDate(request.resource.data.dueDate))
                    && request.resource.data.keys().hasOnly([
                      'userId',
                      'title',
                      'description',
                      'category',
                      'labels',
                      'projectId',
                      'priority',
                      'status',
                      'dueDate',
                      'assignedTo',
                      'progress',
                      'subtasks',
                      'recurrence',
                      'timeEstimate',
                      'actualTime',
                      'pomodoroSessions',
                      'attachments',
                      'createdAt',
                      'updatedAt',
                      'completedAt',
                      'dueDateReminder',
                      'reminderTime'
                    ]);
      
      // Allow update if user owns the task or is assigned to it
      allow update: if isAuthenticated() && (
        resource.data.userId == request.auth.uid ||
        resource.data.assignedTo == request.auth.token.email
      ) && (
        // Owner can update most fields, assignee can only update status and progress
        resource.data.userId == request.auth.uid || (
          request.resource.data.diff(resource.data).affectedKeys().hasOnly([
            'status',
            'progress',
            'updatedAt'
          ])
        )
      ) && (
        request.resource.data.priority == resource.data.priority || 
        isValidPriority(request.resource.data.priority)
      ) && (
        request.resource.data.status == resource.data.status ||
        isValidStatus(request.resource.data.status)
      );
      
      // Allow delete only by owner
      allow delete: if isAuthenticated() && resource.data.userId == request.auth.uid;
    }
    
    // Categories Collection Rules
    match /categories/{categoryId} {
      // Allow read if user owns the category or it's a default category
      allow read: if isAuthenticated() && (
        resource.data.userId == request.auth.uid || 
        resource.data.isDefault == true
      );
      
      // Allow create if user is authenticated
      allow create: if isAuthenticated() 
                    && request.resource.data.userId == request.auth.uid
                    && request.resource.data.keys().hasOnly([
                      'categoryId',
                      'userId',
                      'name',
                      'color',
                      'icon',
                      'isDefault',
                      'sortOrder',
                      'createdAt'
                    ]);
      
      // Allow update only by owner
      allow update: if isAuthenticated() && resource.data.userId == request.auth.uid;
      
      // Allow delete only by owner and not for default categories
      allow delete: if isAuthenticated() && 
                    resource.data.userId == request.auth.uid && 
                    resource.data.isDefault == false;
    }
    
    // Projects Collection Rules
    match /projects/{projectId} {
      // Allow read if user owns the project or is shared with them
      allow read: if isAuthenticated() && (
        resource.data.userId == request.auth.uid ||
        request.auth.token.email in resource.data.sharedWith
      );
      
      // Allow create if user is authenticated
      allow create: if isAuthenticated() 
                    && request.resource.data.userId == request.auth.uid
                    && request.resource.data.keys().hasOnly([
                      'projectId',
                      'userId',
                      'name',
                      'description',
                      'color',
                      'icon',
                      'isFavorite',
                      'viewMode',
                      'sharedWith',
                      'createdAt',
                      'updatedAt'
                    ]);
      
      // Allow update only by owner
      allow update: if isAuthenticated() && resource.data.userId == request.auth.uid;
      
      // Allow delete only by owner
      allow delete: if isAuthenticated() && resource.data.userId == request.auth.uid;
    }
    
    // Habits Collection Rules
    match /habits/{habitId} {
      // Allow read only by owner
      allow read: if isAuthenticated() && resource.data.userId == request.auth.uid;
      
      // Allow create if user is authenticated
      allow create: if isAuthenticated() 
                    && request.resource.data.userId == request.auth.uid
                    && request.resource.data.keys().hasOnly([
                      'habitId',
                      'userId',
                      'name',
                      'description',
                      'icon',
                      'color',
                      'frequency',
                      'targetDays',
                      'reminderTime',
                      'streak',
                      'bestStreak',
                      'completions',
                      'createdAt',
                      'updatedAt'
                    ]);
      
      // Allow update only by owner
      allow update: if isAuthenticated() && resource.data.userId == request.auth.uid;
      
      // Allow delete only by owner
      allow delete: if isAuthenticated() && resource.data.userId == request.auth.uid;
    }
    
    // Ensure data integrity with indexes
    // Create indexes in Firebase Console for:
    // - tasks: userId + status, userId + priority, userId + dueDate
    // - projects: userId + isFavorite
    // - habits: userId + frequency
  }
}
```

## Indexing Recommendations

### Single Field Indexes

```javascript
// Tasks collection
// userId (auto-indexed)
// priority (auto-indexed) 
// status (auto-indexed)
// dueDate (ascending and descending)

// Categories collection
// userId (auto-indexed)
// isDefault (auto-indexed)

// Projects collection
// userId (auto-indexed)
// isFavorite (auto-indexed)

// Habits collection
// userId (auto-indexed)
// frequency (auto-indexed)
```

### Composite Indexes

Create these composite indexes in Firebase Console → Firestore → Indexes:

```javascript
// Tasks composite indexes
tasks
- userId ASC, status ASC
- userId ASC, priority ASC
- userId ASC, dueDate ASC
- userId ASC, createdAt DESC
- assignedTo ASC, status ASC

// Projects composite indexes
projects
- userId ASC, isFavorite DESC
- userId ASC, createdAt DESC

// Habits composite indexes
habits
- userId ASC, frequency ASC
```

## Security Rules Testing

### Test Cases to Verify

1. **User Authentication Tests**
   - ✓ Authenticated user can create their own user document
   - ✓ User cannot create document for another user
   - ✓ User can read and update their own document
   - ✓ Unauthenticated users cannot access any data

2. **Task Management Tests**
   - ✓ User can create tasks with proper validation
   - ✓ User can read their own tasks
   - ✓ User cannot read tasks belonging to other users
   - ✓ Assigned user can read assigned tasks
   - ✓ Assigned user can only update status and progress
   - ✓ Owner can update all task fields
   - ✓ Owner can delete their own tasks

3. **Category Management Tests**
   - ✓ Users can read default categories
   - ✓ Users can create custom categories
   - ✓ Users cannot delete default categories
   - ✓ Users can only manage their own categories

4. **Project Management Tests**
   - ✓ Users can create projects
   - ✓ Shared users can read shared projects
   - ✓ Only owners can update/delete projects
   - ✓ Users cannot access unshared projects

5. **Habit Management Tests**
   - ✓ Users can create and manage their own habits
   - ✓ Users cannot access other users' habits
   - ✓ Only owners can update/delete habits

## Implementation Steps

1. **Copy Rules to Firebase Console**
   - Go to Firebase Console → Firestore → Rules
   - Copy the complete rules from this file
   - Paste into the rules editor
   - Click "Publish"

2. **Test Rules in Simulator**
   - Use the Firebase Console rules simulator
   - Test various scenarios before publishing
   - Verify authentication and authorization work correctly

3. **Monitor for Issues**
   - Check Firebase Console logs
   - Monitor for permission errors
   - Adjust rules if necessary

## Security Best Practices

1. **Always Validate Input**
   - Never trust client-side data
   - Validate data types and values
   - Check for required fields

2. **Use Principle of Least Privilege**
   - Users should only access data they need
   - Assignees have limited permissions
   - Owners have full permissions

3. **Implement Time-Based Validation**
   - Validate timestamps
   - Prevent future date manipulation
   - Ensure proper date formats

4. **Monitor and Audit**
   - Keep track of rule changes
   - Monitor access patterns
   - Set up alerts for suspicious activity

## Migration from Test Mode

When moving from test mode to production:

1. **Ensure all security rules are properly defined**
2. **Test all functionality in development**
3. **Gradually roll out to production**
4. **Monitor for any issues**
5. **Be ready to rollback if needed**

## Important Notes

- These rules assume email authentication
- For other auth providers, adjust the `isAuthenticated()` function
- Always test rules before publishing to production
- Keep rules version controlled
- Document any custom validation requirements
- Review and update rules regularly

This comprehensive security setup ensures that all user data is properly protected while allowing the application to function as intended with proper access controls and data validation.