/**
 * Application Constants for Sadhana
 * Centralized configuration for the entire application
 */

// Priority Levels - Pundit Style
export const PRIORITY_LEVELS = {
  BRAHMA: {
    value: 'brahma',
    label: 'Brahma',
    description: 'Highest - Critical and urgent',
    color: '#E74C3C', // Red
    icon: 'stars',
    urgency: 4
  },
  VISHNU: {
    value: 'vishnu',
    label: 'Vishnu', 
    description: 'High - Important and soon',
    color: '#F39C12', // Orange
    icon: 'grade',
    urgency: 3
  },
  SHIVA: {
    value: 'shiva',
    label: 'Shiva',
    description: 'Medium - Regular tasks',
    color: '#4A90E2', // Blue
    icon: 'radio_button_unchecked',
    urgency: 2
  },
  INDRA: {
    value: 'indra',
    label: 'Indra',
    description: 'Low - Can be scheduled later',
    color: '#2ECC71', // Green
    icon: 'fiber_manual_record',
    urgency: 1
  }
};

// Task Status
export const TASK_STATUS = {
  NOT_STARTED: 'notStarted',
  IN_PROGRESS: 'inProgress',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled'
};

export const TASK_STATUS_LABELS = {
  notStarted: 'Not Started',
  inProgress: 'In Progress',
  completed: 'Completed',
  cancelled: 'Cancelled'
};

// Default Categories
export const DEFAULT_CATEGORIES = [
  { name: 'Work', color: '#4A90E2', icon: 'work' },
  { name: 'Personal', color: '#2ECC71', icon: 'person' },
  { name: 'Spiritual', color: '#FF9933', icon: 'self_improvement' },
  { name: 'Health', color: '#E74C3C', icon: 'favorite' },
  { name: 'Family', color: '#F39C12', icon: 'family_restroom' },
  { name: 'Study', color: '#9B59B6', icon: 'school' },
  { name: 'Other', color: '#95A5A6', icon: 'more_horiz' }
];

// View Modes
export const VIEW_MODES = {
  LIST: 'list',
  BOARD: 'board',
  CALENDAR: 'calendar'
};

// Habit Frequency
export const HABIT_FREQUENCY = {
  DAILY: 'daily',
  WEEKLY: 'weekly',
  CUSTOM: 'custom'
};

// Days of the Week
export const DAYS_OF_WEEK = [
  'Sunday',
  'Monday', 
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday'
];

export const DAYS_OF_WEEK_SHORT = [
  'Sun',
  'Mon',
  'Tue',
  'Wed',
  'Thu',
  'Fri',
  'Sat'
];

// Time Intervals
export const TIME_INTERVALS = {
  TODAY: 'today',
  TOMORROW: 'tomorrow',
  THIS_WEEK: 'thisWeek',
  NEXT_WEEK: 'nextWeek',
  THIS_MONTH: 'thisMonth',
  NO_DATE: 'noDate'
};

// Recurrence Patterns
export const RECURRENCE_PATTERNS = {
  NONE: null,
  DAILY: { frequency: 'daily', interval: 1 },
  WEEKLY: { frequency: 'weekly', interval: 1 },
  MONTHLY: { frequency: 'monthly', interval: 1 },
  WEEKDAYS: { frequency: 'weekly', interval: 1, days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'] }
};

// Pomodoro Settings
export const POMODORO_DEFAULTS = {
  WORK_DURATION: 25, // minutes
  SHORT_BREAK: 5, // minutes
  LONG_BREAK: 15, // minutes
  SESSIONS_BEFORE_LONG_BREAK: 4
};

// Notification Types
export const NOTIFICATION_TYPES = {
  SUCCESS: 'success',
  ERROR: 'error',
  WARNING: 'warning',
  INFO: 'info'
};

// Route Paths
export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  FORGOT_PASSWORD: '/forgot-password',
  DASHBOARD: '/dashboard',
  TASKS: '/tasks',
  TASK_DETAILS: '/tasks/:taskId',
  PROJECTS: '/projects',
  PROJECT_DETAILS: '/projects/:projectId',
  HABITS: '/habits',
  CALENDAR: '/calendar',
  STATISTICS: '/statistics',
  SETTINGS: '/settings',
  PROFILE: '/profile'
};

// Local Storage Keys
export const STORAGE_KEYS = {
  THEME: 'sadhana_theme',
  USER_PREFERENCES: 'sadhana_preferences',
  LAST_LOGIN: 'sadhana_last_login',
  CACHED_TASKS: 'sadhana_cached_tasks',
  OFFLINE_QUEUE: 'sadhana_offline_queue'
};

// Validation Rules
export const VALIDATION = {
  MIN_PASSWORD_LENGTH: 6,
  MAX_PASSWORD_LENGTH: 100,
  MIN_TITLE_LENGTH: 1,
  MAX_TITLE_LENGTH: 200,
  MAX_DESCRIPTION_LENGTH: 2000,
  MAX_CATEGORY_NAME_LENGTH: 50,
  MAX_PROJECT_NAME_LENGTH: 100,
  MAX_HABIT_NAME_LENGTH: 100,
  EMAIL_REGEX: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
};

// Pagination
export const PAGINATION = {
  TASKS_PER_PAGE: 20,
  PROJECTS_PER_PAGE: 12,
  HABITS_PER_PAGE: 10
};

// Date Formats
export const DATE_FORMATS = {
  DISPLAY: 'MMM DD, YYYY',
  DISPLAY_WITH_TIME: 'MMM DD, YYYY HH:mm',
  INPUT: 'YYYY-MM-DD',
  INPUT_WITH_TIME: 'YYYY-MM-DDTHH:mm',
  MONTH_YEAR: 'MMMM YYYY',
  SHORT: 'MM/DD/YYYY'
};

// Export Formats
export const EXPORT_FORMATS = {
  JSON: 'json',
  CSV: 'csv',
  PDF: 'pdf'
};

// App Information
export const APP_INFO = {
  NAME: 'Sadhana',
  NAME_NATIVE: 'साधना',
  VERSION: '1.0.0',
  DESCRIPTION: 'Task management as a spiritual practice',
  TAGLINE: 'Transform tasks into sacred practice'
};

// Keyboard Shortcuts
export const KEYBOARD_SHORTCUTS = {
  NEW_TASK: 'N',
  SEARCH: '/',
  QUICK_ADD: 'Q',
  COMPLETE_TASK: 'C',
  DELETE_TASK: 'D',
  UNDO: 'CmdOrCtrl+Z',
  REDO: 'CmdOrCtrl+Shift+Z',
  SAVE: 'CmdOrCtrl+S',
  LOGOUT: 'CmdOrCtrl+L'
};

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your connection.',
  AUTH_REQUIRED: 'Authentication required. Please login.',
  PERMISSION_DENIED: 'You do not have permission to perform this action.',
  NOT_FOUND: 'The requested resource was not found.',
  VALIDATION_ERROR: 'Please check your input and try again.',
  UNKNOWN_ERROR: 'An unknown error occurred. Please try again.'
};

// Success Messages
export const SUCCESS_MESSAGES = {
  TASK_CREATED: 'Task created successfully',
  TASK_UPDATED: 'Task updated successfully',
  TASK_DELETED: 'Task deleted successfully',
  TASK_COMPLETED: 'Task completed! Keep up the great work!',
  PROJECT_CREATED: 'Project created successfully',
  HABIT_CREATED: 'Habit created successfully',
  SAVED_CHANGES: 'Changes saved successfully',
  EMAIL_SENT: 'Email sent successfully',
  LOGIN_SUCCESS: 'Welcome back!',
  REGISTRATION_SUCCESS: 'Account created successfully',
  LOGOUT_SUCCESS: 'Logged out successfully'
};

// Colors
export const COLORS = {
  PRIMARY: '#FF9933',
  SECONDARY: '#4A90E2',
  SUCCESS: '#2ECC71',
  WARNING: '#F39C12',
  ERROR: '#E74C3C',
  INFO: '#3498DB',
  BACKGROUND: '#FAFAFA',
  SURFACE: '#FFFFFF',
  TEXT: '#2C3E50',
  TEXT_SECONDARY: '#7F8C8D',
  BORDER: '#E0E0E0',
  DIVIDER: '#BDBDBD'
};

// Animations
export const ANIMATIONS = {
  FADE_IN: 'fadeIn 0.3s ease-in',
  FADE_OUT: 'fadeOut 0.3s ease-out',
  SLIDE_IN: 'slideIn 0.3s ease-out',
  SLIDE_OUT: 'slideOut 0.3s ease-in',
  SCALE_IN: 'scaleIn 0.2s ease-out',
  SCALE_OUT: 'scaleOut 0.2s ease-in'
};

// Sort Options
export const SORT_OPTIONS = {
  CREATED_DESC: 'createdDesc',
  CREATED_ASC: 'createdAsc',
  DUE_DATE_ASC: 'dueDateAsc',
  DUE_DATE_DESC: 'dueDateDesc',
  PRIORITY_DESC: 'priorityDesc',
  PRIORITY_ASC: 'priorityAsc',
  TITLE_ASC: 'titleAsc',
  TITLE_DESC: 'titleDesc'
};

export const SORT_LABELS = {
  createdDesc: 'Newest First',
  createdAsc: 'Oldest First',
  dueDateAsc: 'Due Date (Soonest)',
  dueDateDesc: 'Due Date (Latest)',
  priorityDesc: 'Priority (Highest)',
  priorityAsc: 'Priority (Lowest)',
  titleAsc: 'Title (A-Z)',
  titleDesc: 'Title (Z-A)'
};

// Filter Options
export const FILTER_OPTIONS = {
  ALL: 'all',
  TODAY: 'today',
  THIS_WEEK: 'thisWeek',
  OVERDUE: 'overdue',
  COMPLETED: 'completed',
  IN_PROGRESS: 'inProgress',
  NOT_STARTED: 'notStarted'
};

export const FILTER_LABELS = {
  all: 'All Tasks',
  today: 'Today',
  thisWeek: 'This Week',
  overdue: 'Overdue',
  completed: 'Completed',
  inProgress: 'In Progress',
  notStarted: 'Not Started'
};

// Time Estimates
export const TIME_ESTIMATES = [
  { label: '5 minutes', value: 5 },
  { label: '15 minutes', value: 15 },
  { label: '30 minutes', value: 30 },
  { label: '1 hour', value: 60 },
  { label: '2 hours', value: 120 },
  { label: '3 hours', value: 180 },
  { label: '4 hours', value: 240 },
  { label: 'Custom', value: null }
];

// Progress Thresholds
export const PROGRESS_THRESHOLDS = {
  LOW: 25,
  MEDIUM: 50,
  HIGH: 75,
  COMPLETE: 100
};

export default {
  PRIORITY_LEVELS,
  TASK_STATUS,
  TASK_STATUS_LABELS,
  DEFAULT_CATEGORIES,
  VIEW_MODES,
  HABIT_FREQUENCY,
  DAYS_OF_WEEK,
  DAYS_OF_WEEK_SHORT,
  TIME_INTERVALS,
  RECURRENCE_PATTERNS,
  POMODORO_DEFAULTS,
  NOTIFICATION_TYPES,
  ROUTES,
  STORAGE_KEYS,
  VALIDATION,
  PAGINATION,
  DATE_FORMATS,
  APP_INFO,
  KEYBOARD_SHORTCUTS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  COLORS,
  ANIMATIONS,
  SORT_OPTIONS,
  SORT_LABELS,
  FILTER_OPTIONS,
  FILTER_LABELS,
  TIME_ESTIMATES,
  PROGRESS_THRESHOLDS
};