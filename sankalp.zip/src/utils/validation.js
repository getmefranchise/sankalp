import { VALIDATION } from './constants';

/**
 * Validation Utility Functions for Sadhana
 * Input validation and sanitization
 */

// Email validation
export const validateEmail = (email) => {
  if (!email || email.trim() === '') {
    return { isValid: false, error: 'Email is required' };
  }
  
  if (!VALIDATION.EMAIL_REGEX.test(email)) {
    return { isValid: false, error: 'Please enter a valid email address' };
  }
  
  return { isValid: true };
};

// Password validation
export const validatePassword = (password) => {
  if (!password || password.trim() === '') {
    return { isValid: false, error: 'Password is required' };
  }
  
  if (password.length < VALIDATION.MIN_PASSWORD_LENGTH) {
    return { isValid: false, error: `Password must be at least ${VALIDATION.MIN_PASSWORD_LENGTH} characters` };
  }
  
  if (password.length > VALIDATION.MAX_PASSWORD_LENGTH) {
    return { isValid: false, error: `Password must be less than ${VALIDATION.MAX_PASSWORD_LENGTH} characters` };
  }
  
  return { isValid: true };
};

// Confirm password validation
export const validateConfirmPassword = (password, confirmPassword) => {
  if (!confirmPassword || confirmPassword.trim() === '') {
    return { isValid: false, error: 'Please confirm your password' };
  }
  
  if (password !== confirmPassword) {
    return { isValid: false, error: 'Passwords do not match' };
  }
  
  return { isValid: true };
};

// Name validation (display name)
export const validateName = (name) => {
  if (!name || name.trim() === '') {
    return { isValid: false, error: 'Name is required' };
  }
  
  if (name.length < 2) {
    return { isValid: false, error: 'Name must be at least 2 characters' };
  }
  
  if (name.length > 50) {
    return { isValid: false, error: 'Name must be less than 50 characters' };
  }
  
  return { isValid: true };
};

// Task title validation
export const validateTaskTitle = (title) => {
  if (!title || title.trim() === '') {
    return { isValid: false, error: 'Task title is required' };
  }
  
  if (title.length < VALIDATION.MIN_TITLE_LENGTH) {
    return { isValid: false, error: 'Task title is required' };
  }
  
  if (title.length > VALIDATION.MAX_TITLE_LENGTH) {
    return { isValid: false, error: `Task title must be less than ${VALIDATION.MAX_TITLE_LENGTH} characters` };
  }
  
  return { isValid: true };
};

// Task description validation
export const validateTaskDescription = (description) => {
  if (description && description.length > VALIDATION.MAX_DESCRIPTION_LENGTH) {
    return { 
      isValid: false, 
      error: `Description must be less than ${VALIDATION.MAX_DESCRIPTION_LENGTH} characters` 
    };
  }
  
  return { isValid: true };
};

// Category name validation
export const validateCategoryName = (name) => {
  if (!name || name.trim() === '') {
    return { isValid: false, error: 'Category name is required' };
  }
  
  if (name.length > VALIDATION.MAX_CATEGORY_NAME_LENGTH) {
    return { 
      isValid: false, 
      error: `Category name must be less than ${VALIDATION.MAX_CATEGORY_NAME_LENGTH} characters` 
    };
  }
  
  return { isValid: true };
};

// Project name validation
export const validateProjectName = (name) => {
  if (!name || name.trim() === '') {
    return { isValid: false, error: 'Project name is required' };
  }
  
  if (name.length > VALIDATION.MAX_PROJECT_NAME_LENGTH) {
    return { 
      isValid: false, 
      error: `Project name must be less than ${VALIDATION.MAX_PROJECT_NAME_LENGTH} characters` 
    };
  }
  
  return { isValid: true };
};

// Habit name validation
export const validateHabitName = (name) => {
  if (!name || name.trim() === '') {
    return { isValid: false, error: 'Habit name is required' };
  }
  
  if (name.length > VALIDATION.MAX_HABIT_NAME_LENGTH) {
    return { 
      isValid: false, 
      error: `Habit name must be less than ${VALIDATION.MAX_HABIT_NAME_LENGTH} characters` 
    };
  }
  
  return { isValid: true };
};

// Date validation
export const validateDate = (date) => {
  if (!date) {
    return { isValid: true }; // Date is optional
  }
  
  const dateObj = date instanceof Date ? date : new Date(date);
  
  if (isNaN(dateObj.getTime())) {
    return { isValid: false, error: 'Invalid date' };
  }
  
  return { isValid: true };
};

// Color validation (hex color)
export const validateHexColor = (color) => {
  if (!color || color.trim() === '') {
    return { isValid: false, error: 'Color is required' };
  }
  
  const hexColorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
  
  if (!hexColorRegex.test(color)) {
    return { isValid: false, error: 'Please enter a valid hex color (e.g., #FF5733)' };
  }
  
  return { isValid: true };
};

// Priority validation
export const validatePriority = (priority) => {
  const validPriorities = ['brahma', 'vishnu', 'shiva', 'indra'];
  
  if (!priority || !validPriorities.includes(priority)) {
    return { isValid: false, error: 'Please select a valid priority' };
  }
  
  return { isValid: true };
};

// Status validation
export const validateStatus = (status) => {
  const validStatuses = ['notStarted', 'inProgress', 'completed', 'cancelled'];
  
  if (!status || !validStatuses.includes(status)) {
    return { isValid: false, error: 'Please select a valid status' };
  }
  
  return { isValid: true };
};

// Progress validation
export const validateProgress = (progress) => {
  if (progress === undefined || progress === null) {
    return { isValid: true }; // Progress is optional
  }
  
  const numProgress = Number(progress);
  
  if (isNaN(numProgress)) {
    return { isValid: false, error: 'Progress must be a number' };
  }
  
  if (numProgress < 0 || numProgress > 100) {
    return { isValid: false, error: 'Progress must be between 0 and 100' };
  }
  
  return { isValid: true };
};

// Task validation (complete task object)
export const validateTask = (task) => {
  const errors = {};
  
  // Validate required fields
  const titleValidation = validateTaskTitle(task.title);
  if (!titleValidation.isValid) {
    errors.title = titleValidation.error;
  }
  
  // Validate optional fields if provided
  if (task.description) {
    const descValidation = validateTaskDescription(task.description);
    if (!descValidation.isValid) {
      errors.description = descValidation.error;
    }
  }
  
  if (task.priority) {
    const priorityValidation = validatePriority(task.priority);
    if (!priorityValidation.isValid) {
      errors.priority = priorityValidation.error;
    }
  }
  
  if (task.status) {
    const statusValidation = validateStatus(task.status);
    if (!statusValidation.isValid) {
      errors.status = statusValidation.error;
    }
  }
  
  if (task.dueDate) {
    const dateValidation = validateDate(task.dueDate);
    if (!dateValidation.isValid) {
      errors.dueDate = dateValidation.error;
    }
  }
  
  if (task.progress !== undefined && task.progress !== null) {
    const progressValidation = validateProgress(task.progress);
    if (!progressValidation.isValid) {
      errors.progress = progressValidation.error;
    }
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Sanitize string input (remove leading/trailing whitespace)
export const sanitizeString = (input) => {
  if (typeof input !== 'string') return input;
  return input.trim();
};

// Sanitize email
export const sanitizeEmail = (email) => {
  if (typeof email !== 'string') return email;
  return email.toLowerCase().trim();
};

// Validate login form
export const validateLoginForm = (email, password) => {
  const errors = {};
  
  const emailValidation = validateEmail(email);
  if (!emailValidation.isValid) {
    errors.email = emailValidation.error;
  }
  
  const passwordValidation = validatePassword(password);
  if (!passwordValidation.isValid) {
    errors.password = passwordValidation.error;
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Validate registration form
export const validateRegistrationForm = (email, password, confirmPassword, displayName) => {
  const errors = {};
  
  const emailValidation = validateEmail(email);
  if (!emailValidation.isValid) {
    errors.email = emailValidation.error;
  }
  
  const passwordValidation = validatePassword(password);
  if (!passwordValidation.isValid) {
    errors.password = passwordValidation.error;
  }
  
  const confirmValidation = validateConfirmPassword(password, confirmPassword);
  if (!confirmValidation.isValid) {
    errors.confirmPassword = confirmValidation.error;
  }
  
  const nameValidation = validateName(displayName);
  if (!nameValidation.isValid) {
    errors.displayName = nameValidation.error;
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export default {
  validateEmail,
  validatePassword,
  validateConfirmPassword,
  validateName,
  validateTaskTitle,
  validateTaskDescription,
  validateCategoryName,
  validateProjectName,
  validateHabitName,
  validateDate,
  validateHexColor,
  validatePriority,
  validateStatus,
  validateProgress,
  validateTask,
  sanitizeString,
  sanitizeEmail,
  validateLoginForm,
  validateRegistrationForm
};