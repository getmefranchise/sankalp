import { format, parseISO, addDays, startOfWeek, endOfWeek, isSameDay, isToday, isPast, isFuture, addWeeks, addMonths, startOfDay, endOfDay } from 'date-fns';
import { DATE_FORMATS, TIME_INTERVALS } from './constants';

/**
 * Date Utility Functions for Sadhana
 * Helper functions for date manipulation and formatting
 */

// Format date for display
export const formatDateDisplay = (date) => {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, DATE_FORMATS.DISPLAY);
};

// Format date with time for display
export const formatDateTimeDisplay = (date) => {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, DATE_FORMATS.DISPLAY_WITH_TIME);
};

// Format date for input
export const formatDateInput = (date) => {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, DATE_FORMATS.INPUT);
};

// Format date with time for input
export const formatDateTimeInput = (date) => {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, DATE_FORMATS.INPUT_WITH_TIME);
};

// Check if date is today
export const isDateToday = (date) => {
  if (!date) return false;
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return isToday(dateObj);
};

// Check if date is in the past
export const isDatePast = (date) => {
  if (!date) return false;
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return isPast(dateObj) && !isToday(dateObj);
};

// Check if date is in the future
export const isDateFuture = (date) => {
  if (!date) return false;
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return isFuture(dateObj);
};

// Get relative date string
export const getRelativeDateString = (date) => {
  if (!date) return 'No date';
  
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  
  if (isToday(dateObj)) {
    return 'Today';
  } else if (isSameDay(dateObj, addDays(new Date(), 1))) {
    return 'Tomorrow';
  } else if (isDatePast(dateObj)) {
    const daysPast = Math.floor((new Date() - dateObj) / (1000 * 60 * 60 * 24));
    if (daysPast === 1) return 'Yesterday';
    return `${daysPast} days ago`;
  } else {
    const daysFuture = Math.floor((dateObj - new Date()) / (1000 * 60 * 60 * 24));
    if (daysFuture === 1) return 'Tomorrow';
    return `In ${daysFuture} days`;
  }
};

// Get time interval label
export const getTimeIntervalLabel = (interval) => {
  const labels = {
    [TIME_INTERVALS.TODAY]: 'Today',
    [TIME_INTERVALS.TOMORROW]: 'Tomorrow',
    [TIME_INTERVALS.THIS_WEEK]: 'This Week',
    [TIME_INTERVALS.NEXT_WEEK]: 'Next Week',
    [TIME_INTERVALS.THIS_MONTH]: 'This Month',
    [TIME_INTERVALS.NO_DATE]: 'No Date'
  };
  return labels[interval] || 'Select Date';
};

// Get date from time interval
export const getDateFromInterval = (interval) => {
  const now = new Date();
  
  switch (interval) {
    case TIME_INTERVALS.TODAY:
      return now;
    case TIME_INTERVALS.TOMORROW:
      return addDays(now, 1);
    case TIME_INTERVALS.THIS_WEEK:
      return endOfWeek(now);
    case TIME_INTERVALS.NEXT_WEEK:
      return endOfWeek(addWeeks(now, 1));
    case TIME_INTERVALS.THIS_MONTH:
      return endOfDay(addMonths(now, 1));
    case TIME_INTERVALS.NO_DATE:
      return null;
    default:
      return null;
  }
};

// Check if date is overdue
export const isOverdue = (dueDate, status) => {
  if (!dueDate || status === 'completed') return false;
  return isDatePast(dueDate);
};

// Get overdue status text
export const getOverdueText = (dueDate) => {
  if (!dueDate) return '';
  
  const dateObj = typeof date === 'string' ? parseISO(dueDate) : dueDate;
  const daysOverdue = Math.floor((new Date() - dateObj) / (1000 * 60 * 60 * 24));
  
  if (daysOverdue === 0) return 'Overdue today';
  if (daysOverdue === 1) return '1 day overdue';
  return `${daysOverdue} days overdue`;
};

// Format duration in minutes to human readable string
export const formatDuration = (minutes) => {
  if (!minutes) return '';
  
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours > 0 && mins > 0) {
    return `${hours}h ${mins}m`;
  } else if (hours > 0) {
    return `${hours}h`;
  } else {
    return `${mins}m`;
  }
};

// Get dates for current week
export const getCurrentWeekDates = () => {
  const now = new Date();
  const start = startOfWeek(now, { weekStartsOn: 0 }); // Sunday
  const end = endOfWeek(now, { weekStartsOn: 0 });
  
  const dates = [];
  let currentDate = start;
  
  while (currentDate <= end) {
    dates.push(new Date(currentDate));
    currentDate = addDays(currentDate, 1);
  }
  
  return dates;
};

// Get day name
export const getDayName = (date, short = false) => {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return short ? format(dateObj, 'EEE') : format(dateObj, 'EEEE');
};

// Get month name
export const getMonthName = (date, short = false) => {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return short ? format(dateObj, 'MMM') : format(dateObj, 'MMMM');
};

// Format time
export const formatTime = (date) => {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'HH:mm');
};

// Parse time string to date object
export const parseTime = (timeString, baseDate = new Date()) => {
  if (!timeString) return null;
  
  const [hours, minutes] = timeString.split(':').map(Number);
  const date = new Date(baseDate);
  date.setHours(hours, minutes, 0, 0);
  
  return date;
};

// Get time difference between two dates
export const getTimeDifference = (startDate, endDate) => {
  if (!startDate || !endDate) return null;
  
  const start = typeof startDate === 'string' ? parseISO(startDate) : startDate;
  const end = typeof endDate === 'string' ? parseISO(endDate) : endDate;
  
  const diffMs = Math.abs(end - start);
  const diffMins = Math.floor(diffMs / 1000 / 60);
  
  return formatDuration(diffMins);
};

// Check if two dates are the same day
export const isSameDate = (date1, date2) => {
  if (!date1 || !date2) return false;
  const d1 = typeof date1 === 'string' ? parseISO(date1) : date1;
  const d2 = typeof date2 === 'string' ? parseISO(date2) : date2;
  return isSameDay(d1, d2);
};

// Get start of day
export const getStartOfDay = (date) => {
  if (!date) return null;
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return startOfDay(dateObj);
};

// Get end of day
export const getEndOfDay = (date) => {
  if (!date) return null;
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return endOfDay(dateObj);
};

// Format date range
export const formatDateRange = (startDate, endDate) => {
  if (!startDate) return '';
  if (!endDate) return formatDateDisplay(startDate);
  
  const start = typeof startDate === 'string' ? parseISO(startDate) : startDate;
  const end = typeof endDate === 'string' ? parseISO(endDate) : endDate;
  
  const startFormatted = format(start, DATE_FORMATS.DISPLAY);
  const endFormatted = format(end, DATE_FORMATS.DISPLAY);
  
  if (isSameDay(start, end)) {
    return startFormatted;
  }
  
  return `${startFormatted} - ${endFormatted}`;
};

export default {
  formatDateDisplay,
  formatDateTimeDisplay,
  formatDateInput,
  formatDateTimeInput,
  isDateToday,
  isDatePast,
  isDateFuture,
  getRelativeDateString,
  getTimeIntervalLabel,
  getDateFromInterval,
  isOverdue,
  getOverdueText,
  formatDuration,
  getCurrentWeekDates,
  getDayName,
  getMonthName,
  formatTime,
  parseTime,
  getTimeDifference,
  isSameDate,
  getStartOfDay,
  getEndOfDay,
  formatDateRange
};