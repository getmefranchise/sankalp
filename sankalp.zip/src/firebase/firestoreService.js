import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot,
  serverTimestamp,
  increment,
  arrayUnion,
  arrayRemove,
  writeBatch
} from 'firebase/firestore';
import { db } from './firebaseConfig';

/**
 * Firestore Database Service for Sadhana
 * Handles all database operations for tasks, categories, projects, and habits
 */

// ============ TASKS OPERATIONS ============

// Create a new task
export const createTask = async (taskData) => {
  try {
    const task = {
      userId: taskData.userId,
      title: taskData.title,
      description: taskData.description || '',
      category: taskData.category || 'personal',
      labels: taskData.labels || [],
      projectId: taskData.projectId || null,
      priority: taskData.priority || 'shiva',
      status: taskData.status || 'notStarted',
      dueDate: taskData.dueDate || null,
      assignedTo: taskData.assignedTo || null,
      progress: taskData.progress || 0,
      subtasks: taskData.subtasks || [],
      recurrence: taskData.recurrence || null,
      timeEstimate: taskData.timeEstimate || null,
      actualTime: taskData.actualTime || 0,
      pomodoroSessions: taskData.pomodoroSessions || 0,
      attachments: taskData.attachments || [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      completedAt: null,
      dueDateReminder: taskData.dueDateReminder || false,
      reminderTime: taskData.reminderTime || null
    };

    const docRef = await addDoc(collection(db, 'tasks'), task);
    return { success: true, taskId: docRef.id };
  } catch (error) {
    console.error('Create task error:', error);
    return { success: false, error: error.message };
  }
};

// Get all tasks for a user
export const getUserTasks = async (userId) => {
  try {
    const q = query(
      collection(db, 'tasks'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const tasks = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, tasks };
  } catch (error) {
    console.error('Get tasks error:', error);
    return { success: false, error: error.message };
  }
};

// Get a single task by ID
export const getTask = async (taskId) => {
  try {
    const taskDoc = await getDoc(doc(db, 'tasks', taskId));
    if (taskDoc.exists()) {
      return { success: true, task: { id: taskDoc.id, ...taskDoc.data() } };
    } else {
      return { success: false, error: 'Task not found' };
    }
  } catch (error) {
    console.error('Get task error:', error);
    return { success: false, error: error.message };
  }
};

// Update a task
export const updateTask = async (taskId, updates) => {
  try {
    const updateData = {
      ...updates,
      updatedAt: serverTimestamp()
    };
    
    // Set completedAt timestamp if task is being completed
    if (updates.status === 'completed' && !updates.completedAt) {
      updateData.completedAt = serverTimestamp();
    }
    
    await updateDoc(doc(db, 'tasks', taskId), updateData);
    return { success: true };
  } catch (error) {
    console.error('Update task error:', error);
    return { success: false, error: error.message };
  }
};

// Delete a task
export const deleteTask = async (taskId) => {
  try {
    await deleteDoc(doc(db, 'tasks', taskId));
    return { success: true };
  } catch (error) {
    console.error('Delete task error:', error);
    return { success: false, error: error.message };
  }
};

// Get tasks by status
export const getTasksByStatus = async (userId, status) => {
  try {
    const q = query(
      collection(db, 'tasks'),
      where('userId', '==', userId),
      where('status', '==', status),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const tasks = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, tasks };
  } catch (error) {
    console.error('Get tasks by status error:', error);
    return { success: false, error: error.message };
  }
};

// Get tasks by priority
export const getTasksByPriority = async (userId, priority) => {
  try {
    const q = query(
      collection(db, 'tasks'),
      where('userId', '==', userId),
      where('priority', '==', priority),
      orderBy('dueDate', 'asc')
    );
    
    const querySnapshot = await getDocs(q);
    const tasks = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, tasks };
  } catch (error) {
    console.error('Get tasks by priority error:', error);
    return { success: false, error: error.message };
  }
};

// Get tasks by category
export const getTasksByCategory = async (userId, category) => {
  try {
    const q = query(
      collection(db, 'tasks'),
      where('userId', '==', userId),
      where('category', '==', category),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const tasks = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, tasks };
  } catch (error) {
    console.error('Get tasks by category error:', error);
    return { success: false, error: error.message };
  }
};

// Get assigned tasks
export const getAssignedTasks = async (email) => {
  try {
    const q = query(
      collection(db, 'tasks'),
      where('assignedTo', '==', email),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const tasks = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, tasks };
  } catch (error) {
    console.error('Get assigned tasks error:', error);
    return { success: false, error: error.message };
  }
};

// Subscribe to real-time task updates
export const subscribeToTasks = (userId, callback) => {
  const q = query(
    collection(db, 'tasks'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  
  return onSnapshot(q, (snapshot) => {
    const tasks = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    callback(tasks);
  }, (error) => {
    console.error('Task subscription error:', error);
    callback(null, error);
  });
};

// ============ CATEGORIES OPERATIONS ============

// Create default categories for a new user
export const createDefaultCategories = async (userId) => {
  try {
    const defaultCategories = [
      { name: 'Work', color: '#4A90E2', icon: 'work' },
      { name: 'Personal', color: '#2ECC71', icon: 'person' },
      { name: 'Spiritual', color: '#FF9933', icon: 'self_improvement' },
      { name: 'Health', color: '#E74C3C', icon: 'favorite' },
      { name: 'Family', color: '#F39C12', icon: 'family_restroom' },
      { name: 'Study', color: '#9B59B6', icon: 'school' },
      { name: 'Other', color: '#95A5A6', icon: 'more_horiz' }
    ];

    const batch = writeBatch(db);
    
    defaultCategories.forEach(cat => {
      const catRef = doc(collection(db, 'categories'));
      batch.set(catRef, {
        categoryId: catRef.id,
        userId,
        name: cat.name,
        color: cat.color,
        icon: cat.icon,
        isDefault: true,
        sortOrder: defaultCategories.indexOf(cat),
        createdAt: serverTimestamp()
      });
    });

    await batch.commit();
    return { success: true };
  } catch (error) {
    console.error('Create default categories error:', error);
    return { success: false, error: error.message };
  }
};

// Create custom category
export const createCategory = async (categoryData) => {
  try {
    const category = {
      userId: categoryData.userId,
      name: categoryData.name,
      color: categoryData.color || '#95A5A6',
      icon: categoryData.icon || 'label',
      isDefault: false,
      sortOrder: categoryData.sortOrder || 0,
      createdAt: serverTimestamp()
    };

    const docRef = await addDoc(collection(db, 'categories'), category);
    return { success: true, categoryId: docRef.id };
  } catch (error) {
    console.error('Create category error:', error);
    return { success: false, error: error.message };
  }
};

// Get user categories
export const getUserCategories = async (userId) => {
  try {
    const q = query(
      collection(db, 'categories'),
      where('userId', '==', userId),
      orderBy('sortOrder', 'asc')
    );
    
    const querySnapshot = await getDocs(q);
    const categories = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, categories };
  } catch (error) {
    console.error('Get categories error:', error);
    return { success: false, error: error.message };
  }
};

// Update category
export const updateCategory = async (categoryId, updates) => {
  try {
    await updateDoc(doc(db, 'categories', categoryId), updates);
    return { success: true };
  } catch (error) {
    console.error('Update category error:', error);
    return { success: false, error: error.message };
  }
};

// Delete category
export const deleteCategory = async (categoryId) => {
  try {
    await deleteDoc(doc(db, 'categories', categoryId));
    return { success: true };
  } catch (error) {
    console.error('Delete category error:', error);
    return { success: false, error: error.message };
  }
};

// ============ PROJECTS OPERATIONS ============

// Create project
export const createProject = async (projectData) => {
  try {
    const project = {
      userId: projectData.userId,
      name: projectData.name,
      description: projectData.description || '',
      color: projectData.color || '#4A90E2',
      icon: projectData.icon || 'folder',
      isFavorite: false,
      viewMode: 'list',
      sharedWith: projectData.sharedWith || [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    const docRef = await addDoc(collection(db, 'projects'), project);
    return { success: true, projectId: docRef.id };
  } catch (error) {
    console.error('Create project error:', error);
    return { success: false, error: error.message };
  }
};

// Get user projects
export const getUserProjects = async (userId) => {
  try {
    const q = query(
      collection(db, 'projects'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const projects = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, projects };
  } catch (error) {
    console.error('Get projects error:', error);
    return { success: false, error: error.message };
  }
};

// Update project
export const updateProject = async (projectId, updates) => {
  try {
    const updateData = {
      ...updates,
      updatedAt: serverTimestamp()
    };
    
    await updateDoc(doc(db, 'projects', projectId), updateData);
    return { success: true };
  } catch (error) {
    console.error('Update project error:', error);
    return { success: false, error: error.message };
  }
};

// Delete project
export const deleteProject = async (projectId) => {
  try {
    await deleteDoc(doc(db, 'projects', projectId));
    return { success: true };
  } catch (error) {
    console.error('Delete project error:', error);
    return { success: false, error: error.message };
  }
};

// ============ HABITS OPERATIONS ============

// Create habit
export const createHabit = async (habitData) => {
  try {
    const habit = {
      userId: habitData.userId,
      name: habitData.name,
      description: habitData.description || '',
      icon: habitData.icon || 'track_changes',
      color: habitData.color || '#FF9933',
      frequency: habitData.frequency || 'daily',
      targetDays: habitData.targetDays || ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'],
      reminderTime: habitData.reminderTime || null,
      streak: 0,
      bestStreak: 0,
      completions: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    const docRef = await addDoc(collection(db, 'habits'), habit);
    return { success: true, habitId: docRef.id };
  } catch (error) {
    console.error('Create habit error:', error);
    return { success: false, error: error.message };
  }
};

// Get user habits
export const getUserHabits = async (userId) => {
  try {
    const q = query(
      collection(db, 'habits'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const habits = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return { success: true, habits };
  } catch (error) {
    console.error('Get habits error:', error);
    return { success: false, error: error.message };
  }
};

// Update habit completion
export const updateHabitCompletion = async (habitId, date, completed) => {
  try {
    const habitDoc = await getDoc(doc(db, 'habits', habitId));
    if (!habitDoc.exists()) {
      return { success: false, error: 'Habit not found' };
    }

    const habitData = habitDoc.data();
    const completions = habitData.completions || [];
    const existingIndex = completions.findIndex(c => c.date.toDate().toDateString() === date.toDateString());

    if (existingIndex >= 0) {
      // Update existing completion
      completions[existingIndex].completed = completed;
    } else {
      // Add new completion
      completions.push({ date, completed });
    }

    // Calculate streak
    let newStreak = 0;
    const sortedCompletions = completions
      .filter(c => c.completed)
      .sort((a, b) => b.date - a.date);

    if (sortedCompletions.length > 0) {
      newStreak = 1;
      for (let i = 0; i < sortedCompletions.length - 1; i++) {
        const current = sortedCompletions[i].date.toDate();
        const next = sortedCompletions[i + 1].date.toDate();
        const diffDays = Math.floor((current - next) / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          newStreak++;
        } else {
          break;
        }
      }
    }

    const updates = {
      completions,
      streak: newStreak,
      bestStreak: Math.max(newStreak, habitData.bestStreak || 0),
      updatedAt: serverTimestamp()
    };

    await updateDoc(doc(db, 'habits', habitId), updates);
    return { success: true, streak: newStreak };
  } catch (error) {
    console.error('Update habit completion error:', error);
    return { success: false, error: error.message };
  }
};

// Update habit
export const updateHabit = async (habitId, updates) => {
  try {
    await updateDoc(doc(db, 'habits', habitId), updates);
    return { success: true };
  } catch (error) {
    console.error('Update habit error:', error);
    return { success: false, error: error.message };
  }
};

// Delete habit
export const deleteHabit = async (habitId) => {
  try {
    await deleteDoc(doc(db, 'habits', habitId));
    return { success: true };
  } catch (error) {
    console.error('Delete habit error:', error);
    return { success: false, error: error.message };
  }
};

// ============ STATISTICS OPERATIONS ============

// Get task statistics
export const getTaskStatistics = async (userId) => {
  try {
    const tasks = await getUserTasks(userId);
    if (!tasks.success) {
      return { success: false, error: tasks.error };
    }

    const statistics = {
      total: tasks.tasks.length,
      notStarted: 0,
      inProgress: 0,
      completed: 0,
      cancelled: 0,
      byPriority: {
        brahma: 0,
        vishnu: 0,
        shiva: 0,
        indra: 0
      },
      byCategory: {},
      completionRate: 0
    };

    tasks.tasks.forEach(task => {
      // Count by status
      statistics[task.status]++;

      // Count by priority
      if (task.priority && statistics.byPriority[task.priority] !== undefined) {
        statistics.byPriority[task.priority]++;
      }

      // Count by category
      if (task.category) {
        statistics.byCategory[task.category] = (statistics.byCategory[task.category] || 0) + 1;
      }
    });

    // Calculate completion rate
    statistics.completionRate = statistics.total > 0 
      ? Math.round((statistics.completed / statistics.total) * 100) 
      : 0;

    return { success: true, statistics };
  } catch (error) {
    console.error('Get statistics error:', error);
    return { success: false, error: error.message };
  }
};

export default {
  // Tasks
  createTask,
  getUserTasks,
  getTask,
  updateTask,
  deleteTask,
  getTasksByStatus,
  getTasksByPriority,
  getTasksByCategory,
  getAssignedTasks,
  subscribeToTasks,
  
  // Categories
  createDefaultCategories,
  createCategory,
  getUserCategories,
  updateCategory,
  deleteCategory,
  
  // Projects
  createProject,
  getUserProjects,
  updateProject,
  deleteProject,
  
  // Habits
  createHabit,
  getUserHabits,
  updateHabitCompletion,
  updateHabit,
  deleteHabit,
  
  // Statistics
  getTaskStatistics
};