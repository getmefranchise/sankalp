// Firebase Configuration and Services Export
export { app, auth, db, storage, isFirebaseConfigured, getFirebaseProjectInfo } from './firebaseConfig';
export * from './authService';
export { default } from './firestoreService';