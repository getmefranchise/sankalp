import React, { createContext, useContext, useState, useEffect } from 'react';
import { STORAGE_KEYS, COLORS } from '../utils/constants';

/**
 * Theme Context for Sadhana
 * Manages application theme (light/dark mode) and colors
 */

const ThemeContext = createContext(null);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export const ThemeProvider = ({ children }) => {
  const [mode, setMode] = useState('light');
  const [colors, setColors] = useState(COLORS);

  // Load theme preference from localStorage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem(STORAGE_KEYS.THEME);
    if (savedTheme) {
      setMode(savedTheme);
    }
  }, []);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', mode);
    localStorage.setItem(STORAGE_KEYS.THEME, mode);
  }, [mode]);

  // Toggle between light and dark mode
  const toggleTheme = () => {
    setMode(prevMode => prevMode === 'light' ? 'dark' : 'light');
  };

  // Set specific theme
  const setTheme = (newMode) => {
    if (newMode === 'light' || newMode === 'dark') {
      setMode(newMode);
    }
  };

  // Get theme-aware color
  const getThemeColor = (colorName) => {
    if (mode === 'dark') {
      const darkColors = {
        ...colors,
        BACKGROUND: '#121212',
        SURFACE: '#1E1E1E',
        TEXT: '#FFFFFF',
        TEXT_SECONDARY: '#B0B0B0',
        BORDER: '#333333',
        DIVIDER: '#444444'
      };
      return darkColors[colorName] || colors[colorName];
    }
    return colors[colorName];
  };

  const value = {
    mode,
    colors,
    toggleTheme,
    setTheme,
    getThemeColor
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeContext;