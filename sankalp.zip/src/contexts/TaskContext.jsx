import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  createTask, 
  updateTask, 
  deleteTask, 
  getUserTasks,
  subscribeToTasks 
} from '../firebase/firestoreService';
import { useAuth } from './AuthContext';

/**
 * Task Context for Sadhana
 * Manages task state and operations across the application
 */

const TaskContext = createContext(null);

export const useTasks = () => {
  const context = useContext(TaskContext);
  if (!context) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
};

export const TaskProvider = ({ children }) => {
  const { user, authenticated } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load tasks when user is authenticated
  useEffect(() => {
    if (!authenticated || !user) {
      setTasks([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    // Subscribe to real-time task updates
    const unsubscribe = subscribeToTasks(user.uid, (taskList, err) => {
      if (err) {
        console.error('Task subscription error:', err);
        setError(err.message);
        setLoading(false);
      } else {
        setTasks(taskList || []);
        setLoading(false);
      }
    });

    // Cleanup subscription on unmount
    return () => unsubscribe();
  }, [user, authenticated]);

  // Create a new task
  const addTask = async (taskData) => {
    try {
      const result = await createTask({
        ...taskData,
        userId: user.uid
      });

      if (!result.success) {
        throw new Error(result.error || 'Failed to create task');
      }

      return { success: true, taskId: result.taskId };
    } catch (error) {
      console.error('Add task error:', error);
      return { success: false, error: error.message };
    }
  };

  // Update an existing task
  const editTask = async (taskId, updates) => {
    try {
      const result = await updateTask(taskId, updates);

      if (!result.success) {
        throw new Error(result.error || 'Failed to update task');
      }

      return { success: true };
    } catch (error) {
      console.error('Edit task error:', error);
      return { success: false, error: error.message };
    }
  };

  // Delete a task
  const removeTask = async (taskId) => {
    try {
      const result = await deleteTask(taskId);

      if (!result.success) {
        throw new Error(result.error || 'Failed to delete task');
      }

      return { success: true };
    } catch (error) {
      console.error('Delete task error:', error);
      return { success: false, error: error.message };
    }
  };

  // Complete a task
  const completeTask = async (taskId) => {
    try {
      const result = await updateTask(taskId, {
        status: 'completed',
        progress: 100
      });

      if (!result.success) {
        throw new Error(result.error || 'Failed to complete task');
      }

      return { success: true };
    } catch (error) {
      console.error('Complete task error:', error);
      return { success: false, error: error.message };
    }
  };

  // Get task by ID
  const getTaskById = (taskId) => {
    return tasks.find(task => task.id === taskId);
  };

  // Filter tasks by status
  const getTasksByStatus = (status) => {
    return tasks.filter(task => task.status === status);
  };

  // Filter tasks by priority
  const getTasksByPriority = (priority) => {
    return tasks.filter(task => task.priority === priority);
  };

  // Filter tasks by category
  const getTasksByCategory = (category) => {
    return tasks.filter(task => task.category === category);
  };

  // Get today's tasks
  const getTodayTasks = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return tasks.filter(task => {
      if (!task.dueDate) return false;
      const dueDate = task.dueDate instanceof Date ? task.dueDate : task.dueDate.toDate();
      return dueDate >= today && dueDate < new Date(today.getTime() + 24 * 60 * 60 * 1000);
    });
  };

  // Get overdue tasks
  const getOverdueTasks = () => {
    const now = new Date();
    return tasks.filter(task => {
      if (!task.dueDate || task.status === 'completed') return false;
      const dueDate = task.dueDate instanceof Date ? task.dueDate : task.dueDate.toDate();
      return dueDate < now;
    });
  };

  // Get task statistics
  const getTaskStats = () => {
    return {
      total: tasks.length,
      notStarted: tasks.filter(t => t.status === 'notStarted').length,
      inProgress: tasks.filter(t => t.status === 'inProgress').length,
      completed: tasks.filter(t => t.status === 'completed').length,
      cancelled: tasks.filter(t => t.status === 'cancelled').length,
      byPriority: {
        brahma: tasks.filter(t => t.priority === 'brahma').length,
        vishnu: tasks.filter(t => t.priority === 'vishnu').length,
        shiva: tasks.filter(t => t.priority === 'shiva').length,
        indra: tasks.filter(t => t.priority === 'indra').length
      },
      completionRate: tasks.length > 0 
        ? Math.round((tasks.filter(t => t.status === 'completed').length / tasks.length) * 100)
        : 0
    };
  };

  // Search tasks
  const searchTasks = (query) => {
    if (!query || query.trim() === '') return tasks;
    
    const searchLower = query.toLowerCase();
    return tasks.filter(task => 
      task.title.toLowerCase().includes(searchLower) ||
      (task.description && task.description.toLowerCase().includes(searchLower)) ||
      (task.category && task.category.toLowerCase().includes(searchLower))
    );
  };

  const value = {
    tasks,
    loading,
    error,
    addTask,
    editTask,
    removeTask,
    completeTask,
    getTaskById,
    getTasksByStatus,
    getTasksByPriority,
    getTasksByCategory,
    getTodayTasks,
    getOverdueTasks,
    getTaskStats,
    searchTasks
  };

  return (
    <TaskContext.Provider value={value}>
      {children}
    </TaskContext.Provider>
  );
};

export default TaskContext;