# Master Prompt for Building "Sadhana" - Hindu-Themed Task Management Tool

## Role: Senior Full-Stack Developer with Firebase Expertise

You are tasked with building "Sadhana" - a comprehensive, Firebase-powered task management application inspired by Hindu philosophy. This application will help users manage their daily tasks with a simple, elegant interface while incorporating spiritual elements and Pundit-style priority systems.

## Project Context

**Project Name**: Sadhana (साधना)
**Core Philosophy**: Task management as a spiritual practice of daily discipline
**Tech Stack**: React.js, Firebase (Auth, Firestore, Hosting), Modern UI Framework
**Design Philosophy**: Minimalist, efficient, spiritually-informed

## Technical Requirements

### 1. Project Structure Setup
- Initialize a React project using Vite for optimal performance
- Set up Firebase project with proper configuration
- Configure Firebase Authentication (Email/Password)
- Set up Cloud Firestore database
- Implement Firebase Hosting for deployment
- Create modular, scalable folder structure

### 2. Firebase Configuration

**Required Firebase Services:**
- Firebase Authentication (Email/Password)
- Cloud Firestore (Real-time database)
- Firebase Hosting
- Firebase Storage (optional, for future enhancements)

**Security Rules:**
- Implement strict Firestore security rules
- Ensure users can only access their own data
- Validate data before writes
- Implement proper authentication checks

### 3. Core Features Implementation

#### A. Authentication System
- User registration with email/password
- Login/logout functionality
- Password reset via email
- Email verification
- Persistent sessions with proper token management
- Error handling and user feedback

#### B. Task Management Core
- **One-line task creation**: Simple input field at the top of the dashboard
- **Task CRUD operations**: Create, Read, Update, Delete tasks
- **Real-time sync**: All changes reflect instantly across devices
- **Task delegation**: Assign tasks to other users (by email)
- **Progress tracking**: 0-100% progress indicator for each task
- **Status management**: Not Started → In Progress → Completed → Cancelled

#### C. Pundit-Style Priority System
Implement the following priority hierarchy with visual distinctions:

- **Brahma (Highest)**: Red color, urgent visual indicators, appears at top
- **Vishnu (High)**: Orange color, important visual emphasis  
- **Shiva (Medium)**: Blue color, standard importance
- **Indra (Low)**: Green color, can be scheduled later

Each priority level should have:
- Distinct color coding
- Visual badges/indicators
- Automatic sorting (higher priorities appear first)
- Custom icons representing each deity concept

#### D. Task Organization
- **Categories**: Work, Personal, Spiritual, Health, Family, Study, Other
- **Custom categories**: Allow users to create personalized categories
- **Category filtering**: Filter tasks by category
- **Color coding**: Each category has a distinct color
- **Search functionality**: Search tasks by title, description, or category

#### E. Date & Time Management
- **Due dates**: Set and display due dates for tasks
- **Date picker**: User-friendly date selection interface
- **Overdue indicators**: Visual alerts for past-due tasks
- **Today's tasks**: Highlight tasks due today
- **Upcoming tasks**: Show tasks for the next 7 days

### 4. User Interface Design

#### Design Principles:
- **Minimalist**: Clean, uncluttered interface
- **Efficient**: One-click task creation and management
- **Responsive**: Perfect mobile, tablet, and desktop experience
- **Accessible**: WCAG AA compliance, keyboard navigation
- **Spiritual aesthetics**: Subtle Hindu-inspired design elements

#### Key UI Components:

**Dashboard Layout:**
- Header with app name (Sadhana in both English and Devanagari: साधना)
- User profile section with logout option
- One-line task creation input (prominent, easy to access)
- Task list with card-based layout
- Category filter sidebar or dropdown
- Statistics panel showing completion rates

**Task Card Design:**
- Task title (prominent)
- Description (expandable)
- Priority badge (color-coded)
- Category tag
- Due date with overdue alerts
- Progress bar
- Status indicator
- Action buttons (edit, delete, complete)
- Assigned person indicator (if delegated)

**Authentication Screens:**
- Clean, modern login/signup forms
- Password reset flow
- Email verification prompt
- Error messages with helpful guidance

#### Color Scheme:
- **Primary**: Deep saffron (#FF9933) - representing spirituality
- **Secondary**: Calm blue (#4A90E2) - representing wisdom  
- **Success**: Green (#2ECC71) - representing completion
- **Warning**: Amber (#F39C12) - representing urgency
- **Error**: Red (#E74C3C) - representing missed deadlines
- **Background**: Off-white (#FAFAFA) - representing purity
- **Text**: Dark grey (#2C3E50) - for readability

### 5. Database Implementation

#### Firestore Collection Structure:

**users Collection:**
```javascript
users/{userId}
{
  email: string,
  displayName: string,
  createdAt: timestamp,
  lastLogin: timestamp,
  preferences: {
    theme: "light" | "dark",
    defaultPriority: "shiva",
    notificationsEnabled: boolean
  }
}
```

**tasks Collection:**
```javascript
tasks/{taskId}
{
  userId: string,           // Owner of the task
  title: string,            // Task title (required)
  description: string,      // Detailed description (optional)
  category: string,         // Task category
  priority: "brahma" | "vishnu" | "shiva" | "indra",
  status: "notStarted" | "inProgress" | "completed" | "cancelled",
  dueDate: timestamp,       // Due date (optional)
  assignedTo: string,       // Email of assigned person (optional)
  progress: number,         // 0-100 progress percentage
  createdAt: timestamp,
  updatedAt: timestamp,
  completedAt: timestamp
}
```

**categories Collection:**
```javascript
categories/{categoryId}
{
  userId: string,           // Owner of the category
  name: string,             // Category name
  color: string,            // Hex color code
  icon: string,             // Icon identifier
  isDefault: boolean        // Whether it's a system default
}
```

### 6. Advanced Features

#### A. Real-time Updates
- Implement Firestore real-time listeners
- Instant sync across multiple devices
- Optimistic UI updates
- Conflict resolution for concurrent edits

#### B. Offline Support
- Implement offline capability using Firestore offline persistence
- Queue operations when offline
- Sync automatically when connection restored
- Show offline status indicator

#### C. Performance Optimization
- Lazy loading of components
- Pagination for large task lists
- Debounced search functionality
- Memoization of expensive operations
- Image optimization (if attachments added later)

#### D. State Management
- Use React Context API or Redux for global state
- Manage user authentication state
- Handle task list state
- Manage UI state (themes, filters, sorting)

### 7. Security Implementation

#### Firestore Security Rules:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users can only read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Tasks belong to the user who created them
    match /tasks/{taskId} {
      allow read: if request.auth != null && 
        (resource.data.userId == request.auth.uid || 
         request.auth.token.email == resource.data.assignedTo);
      
      allow write: if request.auth != null && 
        (request.resource.data.userId == request.auth.uid || 
         resource.data.userId == request.auth.uid);
    }
    
    // Categories are user-specific
    match /categories/{categoryId} {
      allow read: if request.auth != null && 
        (resource.data.userId == request.auth.uid || resource.data.isDefault == true);
      
      allow write: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
    }
  }
}
```

### 8. Testing Strategy

#### Unit Tests:
- Component testing with React Testing Library
- Function testing for utility functions
- Firebase service mocking

#### Integration Tests:
- Authentication flow testing
- Task CRUD operations
- Real-time sync verification

#### E2E Tests:
- Complete user flows
- Cross-browser testing
- Responsive design testing

### 9. Deployment Instructions

#### Firebase Deployment Steps:
1. Build the React application: `npm run build`
2. Install Firebase CLI: `npm install -g firebase-tools`
3. Initialize Firebase project: `firebase init`
4. Deploy to Firebase Hosting: `firebase deploy`

#### Environment Configuration:
- Use `.env` files for sensitive configuration
- Never commit Firebase credentials to version control
- Use Firebase environment variables for different environments

### 10. Code Quality Standards

#### JavaScript/React Best Practices:
- Use functional components with hooks
- Implement proper error boundaries
- Follow naming conventions (camelCase for variables, PascalCase for components)
- Add JSDoc comments for functions
- Use TypeScript for type safety (optional but recommended)

#### Code Organization:
- Separate business logic from UI components
- Create reusable utility functions
- Implement proper error handling
- Use async/await for asynchronous operations

#### Performance Guidelines:
- Avoid unnecessary re-renders
- Use React.memo and useMemo appropriately
- Implement proper key props in lists
- Lazy load routes and components

### 11. User Experience Requirements

#### Accessibility:
- Keyboard navigation support
- Screen reader compatibility
- High contrast color ratios
- Focus indicators on interactive elements
- ARIA labels for screen readers

#### Responsiveness:
- Mobile-first design approach
- Touch-friendly interface elements
- Proper viewport meta tags
- Responsive images and layouts

#### Loading States:
- Skeleton loaders for initial data
- Loading spinners for operations
- Error states with retry options
- Empty states with helpful guidance

### 12. Additional Considerations

#### Analytics:
- Implement Firebase Analytics for user insights
- Track key user actions
- Monitor performance metrics

#### Error Handling:
- Global error boundary
- User-friendly error messages
- Proper logging for debugging
- Graceful degradation

#### Internationalization:
- Consider future support for multiple languages
- Use proper text management system
- Support RTL languages if needed

## Deliverables Checklist

- [ ] Complete React application with all features
- [ ] Firebase project setup and configuration
- [ ] Authentication system (login, signup, password reset)
- [ ] Task management core functionality
- [ ] Pundit-style priority system
- [ ] Category management system
- [ ] Real-time updates and offline support
- [ ] Responsive and accessible UI
- [ ] Firebase security rules
- [ ] Deployment configuration
- [ ] Complete documentation
- [ ] Testing suite
- [ ] User guide

## Success Criteria

- Users can create, read, update, and delete tasks
- Authentication works seamlessly with proper security
- Real-time updates function across multiple devices
- Pundit-style priority system is intuitive and effective
- Application is fully responsive and accessible
- Deployment process is straightforward
- Code is clean, documented, and maintainable
- Performance meets industry standards (load time < 3s)

## Important Notes

1. **Simplicity First**: Focus on core functionality over complex features
2. **User Experience**: Every feature should enhance the user's productivity
3. **Performance**: Optimize for speed and efficiency
4. **Security**: Never compromise on security measures
5. **Scalability**: Design for future growth and enhancements
6. **Testing**: Ensure comprehensive test coverage
7. **Documentation**: Keep code and external documentation up to date

This master prompt provides everything needed to build a complete, production-ready task management application called "Sadhana" that combines modern technology with spiritual philosophy. Focus on creating an intuitive, beautiful, and functional application that helps users achieve their daily tasks with purpose and mindfulness.