# Firebase Setup Guide for Sadhana Task Manager

## Step 1: Create Firebase Project

1. **Go to Firebase Console**
   - Visit https://console.firebase.google.com/
   - Sign in with your Google account
   - Click "Add project" button

2. **Configure Project**
   - Enter project name: `sadhana-task-manager`
   - Accept Firebase terms (checkbox)
   - Click "Continue"
   - Choose Google Analytics (optional but recommended)
   - Select or create Google Analytics account
   - Click "Create project"
   - Wait for project creation to complete

## Step 2: Set Up Authentication

1. **Enable Email/Password Authentication**
   - In Firebase Console, go to your project
   - Click "Authentication" in the left sidebar
   - Click "Get Started"
   - Select "Sign-in method" tab
   - Click "Email/Password"
   - Enable the toggle
   - Click "Save"

2. **Configure Email Verification**
   - In Authentication settings, go to "Templates" tab
   - Select "Email address verification" template
   - Customize the verification email if needed
   - Ensure "Email verification" is enabled in settings

3. **Configure Password Reset**
   - In "Templates" tab, select "Password reset" template
   - Customize the reset email with your branding
   - Ensure password reset flow is enabled

## Step 3: Create Firestore Database

1. **Create Database**
   - In Firebase Console, click "Firestore Database" in left sidebar
   - Click "Create database"
   - Select location (choose nearest to your users)
   - Click "Next"

2. **Choose Security Mode**
   - Select "Start in Test mode" (allows full read/write access)
   - Read the security warning
   - Click "Enable"
   - **Important**: Update security rules before production deployment

3. **Database Structure Overview**
   - Collections will be created automatically by the application
   - Collections: `users`, `tasks`, `categories`, `projects`, `habits`

## Step 4: Enable Firebase Hosting

1. **Set Up Hosting**
   - In Firebase Console, click "Hosting" in left sidebar
   - Click "Get Started"
   - Review hosting features
   - Click "Continue"

2. **Install Firebase CLI**
   ```bash
   npm install -g firebase-tools
   ```

3. **Initialize Firebase Project**
   ```bash
   firebase login
   firebase init
   ```

4. **Configuration Options**
   - Select "Hosting" and "Firestore" from the list
   - Select your Firebase project (sadhana-task-manager)
   - Use "public" as your public directory
   - Configure as a single-page app: Yes
   - Configure with automatic builds: No

## Step 5: Get Firebase Configuration

1. **Access Project Settings**
   - In Firebase Console, click gear icon (Project Settings)
   - Scroll down to "Your apps" section
   - Click web icon (</>) to add a web app

2. **Register App**
   - Enter app nickname: `sadhana-web`
   - Check "Also set up Firebase Hosting for this app"
   - Click "Register app"

3. **Get Configuration Code**
   - Copy the Firebase configuration object
   - It should look like:
   ```javascript
   const firebaseConfig = {
     apiKey: "YOUR_API_KEY",
     authDomain: "your-project.firebaseapp.com",
     projectId: "your-project-id",
     storageBucket: "your-project.appspot.com",
     messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
     appId: "YOUR_APP_ID"
   };
   ```

## Step 6: Set Up Firestore Security Rules

1. **Access Security Rules**
   - In Firebase Console, go to Firestore Database
   - Click "Rules" tab
   - Replace default rules with secure rules

2. **Copy Security Rules**
   - Use the security rules provided in the FIREBASE_SECURITY_RULES.md file
   - These rules ensure users can only access their own data
   - Always test rules in simulator before publishing

## Step 7: Initialize React Project

1. **Create React App with Vite**
   ```bash
   npm create vite@latest sadhana-app -- --template react
   cd sadhana-app
   npm install
   ```

2. **Install Required Dependencies**
   ```bash
   # Firebase
   npm install firebase

   # UI Framework
   npm install @mui/material @emotion/react @emotion/styled

   # Icons
   npm install @mui/icons-material

   # Routing
   npm install react-router-dom

   # Date handling
   npm install date-fns

   # State management
   npm install zustand

   # Form handling
   npm install react-hook-form

   # Natural language parsing
   npm install chrono-node

   # Authentication
   npm install firebaseui
   ```

## Step 8: Configure Firebase in React App

1. **Create Firebase Configuration File**
   - Create `src/firebase/firebaseConfig.js`
   - Paste your Firebase configuration
   - Export the configured app

2. **Create Firebase Services**
   - Create `src/firebase/auth.js` for authentication
   - Create `src/firebase/firestore.js` for database operations
   - Create `src/firebase/index.js` to export everything

## Step 9: Environment Setup

1. **Create .env File**
   ```bash
   # In project root
   touch .env
   ```

2. **Add Environment Variables**
   ```env
   VITE_FIREBASE_API_KEY=your_api_key
   VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=your-project-id
   VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
   VITE_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
   VITE_FIREBASE_APP_ID=your_app_id
   ```

3. **Update .gitignore**
   ```
   # Add to .gitignore
   .env
   .env.local
   .firebase/
   firebase-debug.log
   ```

## Step 10: Test Firebase Connection

1. **Create Test Component**
   ```bash
   # Create src/FirebaseTest.js
   # Add code to test Firebase connection
   ```

2. **Run Development Server**
   ```bash
   npm run dev
   ```

3. **Verify Connection**
   - Check browser console for Firebase initialization
   - Test authentication with a test user
   - Verify Firestore database writes

## Step 11: Deployment Preparation

1. **Build for Production**
   ```bash
   npm run build
   ```

2. **Test Production Build Locally**
   ```bash
   npm run preview
   ```

3. **Deploy to Firebase Hosting**
   ```bash
   firebase deploy
   ```

## Step 12: Post-Deployment Configuration

1. **Update Security Rules**
   - Change from Test mode to Production rules
   - Use rules from FIREBASE_SECURITY_RULES.md

2. **Enable Analytics**
   - Set up Google Analytics in Firebase Console
   - Configure events for user actions

3. **Configure App Check** (Optional for enhanced security)
   - Enable App Check in Firebase Console
   - Integrate App Check SDK in your app

## Troubleshooting

### Common Issues:

1. **Authentication Errors**
   - Verify Email/Password is enabled
   - Check API key is correct
   - Ensure Firebase Auth is properly initialized

2. **Firestore Connection Issues**
   - Check security rules permissions
   - Verify project ID matches
   - Ensure database is created

3. **Deployment Failures**
   - Check Firebase CLI is installed
   - Verify you're logged in: `firebase login --list`
   - Check build output is correct

4. **Environment Variables Not Loading**
   - Ensure .env file is in project root
   - Variables must start with `VITE_`
   - Restart development server after changes

## Best Practices

1. **Security**
   - Never commit .env files to version control
   - Use environment-specific Firebase projects
   - Regularly review and update security rules

2. **Performance**
   - Enable Firestore offline persistence
   - Use proper indexing for complex queries
   - Implement pagination for large datasets

3. **Monitoring**
   - Set up Firebase Crashlytics
   - Monitor usage in Firebase Console
   - Set up alerts for unusual activity

4. **Backups**
   - Regular export of Firestore data
   - Document Firebase configuration
   - Keep security rules version controlled

## Next Steps

After completing Firebase setup:

1. Proceed to implement authentication system
2. Create Firestore database services
3. Build task management components
4. Implement UI with Material-UI
5. Test all features thoroughly
6. Deploy to production Firebase hosting

This setup provides a solid foundation for building the Sadhana task management application with all the necessary Firebase services properly configured.