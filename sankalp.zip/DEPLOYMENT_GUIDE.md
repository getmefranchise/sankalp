# Complete Deployment Guide for Sadhana Task Manager

## Overview

This guide will walk you through deploying **Sadhana** (साधना), a Hindu-themed task management application built with React and Firebase. Follow these steps to deploy your application to Firebase Hosting.

## Prerequisites

Before you begin, ensure you have:
- Node.js 18.x or higher installed
- npm or yarn package manager
- Google account for Firebase
- Git (optional, for version control)
- Text editor (VS Code recommended)

## Step-by-Step Deployment Process

### Step 1: Set Up Firebase Project

1. **Go to Firebase Console**
   - Visit https://console.firebase.google.com/
   - Sign in with your Google account
   - Click "Add project"

2. **Create Project**
   - Project name: `sadhana-task-manager`
   - Accept Firebase terms
   - Enable Google Analytics (recommended)
   - Click "Create project"

3. **Enable Required Services**
   - Go to Authentication → Enable Email/Password
   - Go to Firestore Database → Create database in Test mode
   - Go to Hosting → Get Started

### Step 2: Create React Application

```bash
# Create new React project with Vite
npm create vite@latest sadhana-app -- --template react
cd sadhana-app

# Install required dependencies
npm install firebase
npm install react-router-dom
npm install @mui/material @emotion/react @emotion/styled
npm install @mui/icons-material
npm install date-fns
npm install zustand
npm install react-hook-form
npm install chrono-node
```

### Step 3: Configure Environment Variables

Create a `.env` file in your project root:

```env
VITE_FIREBASE_API_KEY=your_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id_here
VITE_FIREBASE_APP_ID=your_app_id_here
```

**Get these values from:**
1. Firebase Console → Project Settings → General
2. Scroll to "Your apps" section
3. Click web icon (</>) to add a web app
4. Copy the configuration object

### Step 4: Copy Project Files

Copy the following files/folders from the provided documentation to your project:

#### Firebase Configuration
- `src/firebase/firebaseConfig.js`
- `src/firebase/authService.js`
- `src/firebase/firestoreService.js`
- `src/firebase/index.js`

#### Contexts
- `src/contexts/AuthContext.jsx`
- `src/contexts/TaskContext.jsx`
- `src/contexts/ThemeContext.jsx`

#### Utilities
- `src/utils/constants.js`
- `src/utils/dateUtils.js`
- `src/utils/validation.js`

#### Main Application Files
- Update `src/main.jsx` with provider setup
- Update `src/App.jsx` with routing
- Update `src/index.css` with global styles

### Step 5: Set Up Firebase Security Rules

1. **Go to Firebase Console → Firestore Database → Rules**
2. **Copy the security rules** from `FIREBASE_SECURITY_RULES.md`
3. **Paste into the rules editor**
4. **Click "Publish"**

### Step 6: Install Firebase CLI

```bash
# Install Firebase CLI globally
npm install -g firebase-tools

# Login to Firebase
firebase login
```

### Step 7: Initialize Firebase in Project

```bash
# Initialize Firebase in your project directory
firebase init

# Follow these prompts:
# ? Which Firebase features do you want to set up?
#   ◉ Hosting
#   ◉ Firestore
#   ◉ Functions (optional)

# ? Select a default Firebase project
#   sadhana-task-manager

# ? What do you want to use as your public directory?
#   dist

# ? Configure as a single-page app?
#   Yes

# ? Set up automatic builds with GitHub?
#   No
```

### Step 8: Build Application

```bash
# Install all dependencies
npm install

# Build for production
npm run build
```

### Step 9: Deploy to Firebase

```bash
# Deploy to Firebase Hosting
firebase deploy

# You'll see output like:
# ✔ Deploy complete!
# 
# Project Console: https://console.firebase.google.com/project/sadhana-task-manager/overview
# Hosting URL: https://sadhana-task-manager.web.app
```

### Step 10: Post-Deployment Configuration

1. **Update Security Rules**
   - Change from Test mode to production rules
   - Use the provided security rules from documentation

2. **Enable Analytics**
   - Set up Google Analytics in Firebase Console
   - Configure events for user actions

3. **Configure App Check** (Optional for enhanced security)
   - Enable App Check in Firebase Console
   - Integrate App Check SDK in your app

## Testing Your Deployment

### 1. Test Authentication
- Navigate to your deployed URL
- Try registering a new account
- Test login/logout functionality
- Verify email verification works

### 2. Test Task Management
- Create a new task
- Update task details
- Test priority changes
- Verify category assignment

### 3. Test Real-time Updates
- Open the app in multiple browsers
- Make changes in one browser
- Verify updates appear in other browsers

### 4. Test Responsive Design
- Test on mobile devices
- Test on tablets
- Test on different screen sizes

## Troubleshooting

### Common Issues and Solutions

**1. Firebase Configuration Errors**
```bash
# Error: Firebase is not properly configured
# Solution: Check .env file has all required variables
# Verify values match Firebase Console
```

**2. Build Failures**
```bash
# Error: Build fails with dependency issues
# Solution: Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

**3. Deployment Failures**
```bash
# Error: firebase deploy fails
# Solution: Check Firebase CLI version
npm update -g firebase-tools
firebase logout
firebase login
```

**4. Firestore Permission Denied**
```bash
# Error: Missing or insufficient permissions
# Solution: Review security rules in Firebase Console
# Ensure rules allow user access to their own data
```

**5. Authentication Issues**
```bash
# Error: Auth/user-not-found
# Solution: Enable Email/Password authentication in Firebase Console
# Check email verification settings
```

## Customization Options

### 1. Branding and Design
- Update `src/utils/constants.js` for colors and themes
- Modify Material-UI theme in `src/styles/theme.js`
- Add custom CSS in `src/index.css`

### 2. Firebase Configuration
- Add additional Firebase services as needed
- Configure Cloud Functions for backend logic
- Set up Firebase Storage for file uploads

### 3. Features
- Enable Google/Facebook authentication
- Add more productivity features
- Implement advanced analytics

## Maintenance and Updates

### Regular Maintenance Tasks

1. **Monitor Usage**
   - Check Firebase Console regularly
   - Monitor storage and database usage
   - Review analytics and user behavior

2. **Security Updates**
   - Keep dependencies updated
   - Review and update security rules
   - Monitor for security vulnerabilities

3. **Performance Optimization**
   - Monitor load times
   - Optimize bundle size
   - Implement caching strategies

### Updating the Application

```bash
# Pull latest changes (if using git)
git pull origin main

# Install updated dependencies
npm install

# Test changes locally
npm run dev

# Build for production
npm run build

# Deploy to Firebase
firebase deploy
```

## Scaling Considerations

### When to Scale Up

1. **User Growth**
   - Consider upgrading Firebase Blaze plan
   - Implement database indexes for better performance
   - Add CDN for static assets

2. **Feature Expansion**
   - Add Cloud Functions for backend logic
   - Implement Firebase Extensions
   - Consider microservices architecture

3. **Performance Optimization**
   - Implement lazy loading
   - Use service workers for offline support
   - Add error monitoring

## Backup and Recovery

### Firebase Data Backup

```bash
# Install Firebase Tools
npm install -g firebase-tools

# Export Firestore data
firestore export --backup-file=backup-$(date +%Y%m%d)

# Backup Firebase configuration
firebase apps:sdkconfig web sadhana-task-manager > firebase-config.json
```

### Recovery Procedures

1. **Database Recovery**
   - Use Firebase Console to restore data
   - Restore from backup files
   - Implement incremental backups

2. **Configuration Recovery**
   - Keep Firebase configuration backed up
   - Document all custom configurations
   - Version control security rules

## Monitoring and Analytics

### Key Metrics to Monitor

1. **User Metrics**
   - Daily active users
   - User retention rates
   - Task completion rates

2. **Technical Metrics**
   - Page load times
   - Error rates
   - Database query performance

3. **Business Metrics**
   - User satisfaction
   - Feature usage
   - Conversion rates

## Cost Management

### Firebase Pricing

**Free Tier (Spark Plan)**
- Authentication: 10,000 verifications/month
- Firestore: 50K reads, 20K writes/day
- Hosting: 10GB/month
- Storage: 5GB

**Paid Tier (Blaze Plan)**
- Pay-as-you-go pricing
- Better performance
- More generous limits

### Cost Optimization Tips

1. **Database Optimization**
   - Implement proper indexing
   - Use efficient queries
   - Cache frequently accessed data

2. **Hosting Optimization**
   - Optimize bundle size
   - Use compression
   - Implement CDN

3. **Storage Optimization**
   - Compress images
   - Use efficient formats
   - Implement cleanup policies

## Support and Resources

### Official Documentation
- Firebase Documentation: https://firebase.google.com/docs
- React Documentation: https://react.dev
- Material-UI Documentation: https://mui.com

### Community Support
- Firebase Community: https://firebase.community
- Stack Overflow: https://stackoverflow.com/questions/tagged/firebase
- GitHub Issues: Report bugs and feature requests

### Emergency Contacts
- Firebase Support: https://firebase.google.com/support
- Google Cloud Support: Included with paid plans

## Conclusion

Following this guide will help you successfully deploy your Sadhana task management application. The combination of React for the frontend and Firebase for the backend provides a robust, scalable, and cost-effective solution for personal and professional task management.

Remember to:
- Test thoroughly before deploying
- Monitor performance regularly
- Keep dependencies updated
- Back up data regularly
- Plan for scaling as you grow

Your Sadhana application is now ready to help users transform their daily tasks into sacred practice! 🙏